### Hexlet tests and linter status:
[![Actions Status](https://github.com/KonstantinShevlyakov/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/KonstantinShevlyakov/python-project-49/actions)

### Maintainability:
[![Maintainability](https://api.codeclimate.com/v1/badges/05345e9a4acaeaaaa4a7/maintainability)](https://codeclimate.com/github/KonstantinShevlyakov/python-project-49/maintainability)

### Brain Even Game
[![asciicast](https://asciinema.org/a/p4yjBWEqZTXhubvLxchW5qAtS.svg)](https://asciinema.org/a/p4yjBWEqZTXhubvLxchW5qAtS)

### Brain Calc Game
[![asciicast](https://asciinema.org/a/YqggFU3SCz7b9bD4htsCSGU3E.svg)](https://asciinema.org/a/YqggFU3SCz7b9bD4htsCSGU3E)
