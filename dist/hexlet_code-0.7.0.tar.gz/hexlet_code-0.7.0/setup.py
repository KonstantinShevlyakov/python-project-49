# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.7.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/KonstantinShevlyakov/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/KonstantinShevlyakov/python-project-49/actions)\n\n### Maintainability:\n[![Maintainability](https://api.codeclimate.com/v1/badges/05345e9a4acaeaaaa4a7/maintainability)](https://codeclimate.com/github/KonstantinShevlyakov/python-project-49/maintainability)\n\n### Brain Even Game\n[![asciicast](https://asciinema.org/a/p4yjBWEqZTXhubvLxchW5qAtS.svg)](https://asciinema.org/a/p4yjBWEqZTXhubvLxchW5qAtS)\n\n### Brain Calc Game\n[![asciicast](https://asciinema.org/a/YqggFU3SCz7b9bD4htsCSGU3E.svg)](https://asciinema.org/a/YqggFU3SCz7b9bD4htsCSGU3E)\n\n### Brain GCD Game\n[![asciicast](https://asciinema.org/a/k7ZFBB28EtGEM6RoYaL7cCy8K.svg)](https://asciinema.org/a/k7ZFBB28EtGEM6RoYaL7cCy8K)\n',
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
